package insertionsort;

import java.util.Arrays;

public class Main {
     public static void main(String[] args) {
         
        int[] array = {8, 1, 6, 3, 5, 2};
        
        InsertionSort insertionSort = new InsertionSort();
        
        // Ascending order (Swap)
        int[] arrayAsc = Arrays.copyOf(array, 6);
        insertionSort.insertionSortAsc(arrayAsc);
        System.out.println("Insertion Sort (Swap) Ascending Order  : " + Arrays.toString(arrayAsc));
        
        // Descending order (Swap)
        int[] arrayDesc = Arrays.copyOf(array, 6);
        insertionSort.insertionSortDesc(arrayDesc);
        System.out.println("Insertion Sort (Swap) Descending Order  : " + Arrays.toString(arrayDesc));

        InsertionSortOP insertionSortOP = new InsertionSortOP();

        // Ascending order (Optimized)
        int[] arrOPAsc = Arrays.copyOf(array, 6);
        insertionSortOP.insertionSortOPAsc(arrOPAsc);
        System.out.println("Insertion Sort (Optimized) Ascending Order  : " + Arrays.toString(arrOPAsc));

        // Descending order (Optimized)
        int[] arrOPDesc = Arrays.copyOf(array, 6);
        insertionSortOP.insertionSortOPDesc(arrOPDesc);
        System.out.println("InsertionSort (Optimized) Descending Order  : " + Arrays.toString(arrOPDesc));
    }
}