package insertionsort;

public class InsertionSort {
    
     // Swap for Dscending order 
    
    public void insertionSortAsc(int[] array) {
        for (int i=1; i<6; i++) {
            int j=i;
            while (j>0 && array[j-1] > array[j]) {
                swap(array, j, j-1);
                j--;
            }
        }
    }
    
    
    
     // Swap for Descending order 
    
    public void insertionSortDesc(int[] array) {
        for (int i=1; i<6; i++) {
            int j=i;
            while (j>0 && array[j-1] < array[j]) {
                swap(array, j, j-1);
                j--;
            }
        }
    }
    
    
    // Swap method
    private void swap(int[] array, int i, int j) {
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
    
}