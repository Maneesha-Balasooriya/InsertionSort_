package insertionsort;


public class InsertionSortOP {
    
    // Optimised method for Assending Order 
    
    public void insertionSortOPAsc(int[] array) {
        for (int i=1; i<6; i++) {
            int key = array[i];
            int j=i-1;
            while (j>=0 && array[j] > key) {
                array[j+1] = array[j];
                j--;
            }
            array[j+1] = key;
        }
    }
    
    
    
    // Optimised method for Dessending Order 
    
    public void insertionSortOPDesc(int[] array) {
        for (int i=1; i<6; i++) {
            int key = array[i];
            int j = i-1;
            while (j>=0 && array[j] < key) {
                array[j+1] = array[j];
                j--;
            }
            array[j+1] = key;
        }
    }
    
}